# Valorant Trigger Bot

The password is: **123necrum**
Feel free to join my Discord server: **https://discord.gg/jUP3DpZQbN**
Discord Tag: __SushiiRolly__
Thank you for using and expanding the community.

No plan how to set it up